MXI JIZZAX — ANDROID ILOVA LOYIHASI
===================================

MUHIM:
Bu arxiv Android Studio orqali APK kompilyatsiya qilish uchun tayyor loyiha.
Ushbu ish muhiti Android SDK/Build Tools va Gradle'ni o'z ichiga olmaydi, shuning
uchun tayyor .apk fayli bu yerda kompilyatsiya qilinmadi. Buning o'rniga loyiha
va GitHub Actions orqali APK yig'ish workflow'i qo'shildi.

OFFLINE ISHLASH:
- Jadval ma'lumotlari ilova ichiga joylangan.
- Tailwind CSS va ikonlar lokal fayllarga yig'ilgan.
- AndroidManifest.xml INTERNET ruxsatini so'ramaydi.
- Sinf tanlovi va rang rejimi localStorage orqali qurilmada saqlanadi.
- CSV eksport Android fayl saqlash oynasini ochadi.
- Jadvalni ulashish Android ulashish oynasi orqali ishlaydi.
- Chop etish Android Print / PDF oynasini ochadi.

ANDROID STUDIO ORQALI APK YARATISH:
1. Android Studio'ni kompyuterga o'rnating.
2. Ushbu arxivni papkaga oching.
3. Android Studio'da Open ni bosing va android loyiha papkasini tanlang.
4. SDK Manager orqali Android SDK Platform 35 o'rnatilganini tekshiring.
5. Gradle sinxronizatsiyasi tugagach, Build > Build Bundle(s) / APK(s) > Build APK(s) ni tanlang.
6. APK odatda app/build/outputs/apk/debug/app-debug.apk ichida paydo bo'ladi.
7. APK'ni telefonga yuborib o'rnating. Android sozlamalarida shu manbadan ilova o'rnatishga ruxsat so'ralishi mumkin.

GITHUB ACTIONS ORQALI APK YIG'ISH:
1. GitHub'da yangi repository yarating.
2. Shu android papkasidagi barcha fayllarni repository'ga yuklang (yashirin .github papkasi ham kerak).
3. main yoki master branch'ga yuboring.
4. Repository ichidagi Actions bo'limidan "Build MXI Jizzax APK" workflow'ini oching.
5. Build tugagach, MXI-Jizzax-debug-APK artifact'ini yuklab oling va ichidan app-debug.apk faylini oling.

ILOVA:
- Nomi: MXI Jizzax
- Package ID: uz.mxi.jizzax.debug (debug APK)
- Minimal Android: 6.0 (API 23)
- SDK: 35
