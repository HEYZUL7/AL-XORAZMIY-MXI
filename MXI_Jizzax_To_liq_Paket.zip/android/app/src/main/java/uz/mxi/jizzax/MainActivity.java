package uz.mxi.jizzax;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int CREATE_CSV_REQUEST = 6201;
    private WebView webView;
    private byte[] pendingCsv;
    private String pendingCsvName = "MXI-jadval.csv";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(8, 13, 32));
        window.setNavigationBarColor(Color.rgb(8, 13, 32));
        window.getDecorView().setSystemUiVisibility(0);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(8, 13, 32));
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setDefaultTextEncodingName("UTF-8");
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    private class AndroidBridge {
        @JavascriptInterface
        public void shareText(String message) {
            runOnUiThread(() -> {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("text/plain");
                send.putExtra(Intent.EXTRA_TEXT, message);
                startActivity(Intent.createChooser(send, "MXI Jizzax jadvalini ulashish"));
            });
        }

        @JavascriptInterface
        public void saveCsv(String csv, String fileName) {
            runOnUiThread(() -> {
                pendingCsv = csv.getBytes(StandardCharsets.UTF_8);
                pendingCsvName = (fileName == null || fileName.trim().isEmpty()) ? "MXI-jadval.csv" : fileName;
                Intent create = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                create.addCategory(Intent.CATEGORY_OPENABLE);
                create.setType("text/csv");
                create.putExtra(Intent.EXTRA_TITLE, pendingCsvName);
                startActivityForResult(create, CREATE_CSV_REQUEST);
            });
        }

        @JavascriptInterface
        public void printPage() {
            runOnUiThread(() -> {
                try {
                    PrintManager printManager = (PrintManager) getSystemService(PRINT_SERVICE);
                    if (printManager == null || webView == null) {
                        Toast.makeText(MainActivity.this, "Chop etish xizmati topilmadi", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    PrintAttributes attributes = new PrintAttributes.Builder()
                            .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                            .setResolution(new PrintAttributes.Resolution("mxi", "MXI PDF", 300, 300))
                            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                            .build();
                    printManager.print("MXI_Jizzax_Jadvali", webView.createPrintDocumentAdapter("MXI Jizzax"), attributes);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Chop etishda xatolik yuz berdi", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CREATE_CSV_REQUEST) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingCsv != null) {
                Uri uri = data.getData();
                try (OutputStream output = getContentResolver().openOutputStream(uri)) {
                    if (output == null) throw new IllegalStateException("Faylga yozib bo‘lmadi");
                    output.write(pendingCsv);
                    Toast.makeText(this, "CSV fayl saqlandi", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(this, "CSV faylni saqlab bo‘lmadi", Toast.LENGTH_LONG).show();
                }
            }
            pendingCsv = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidBridge");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
