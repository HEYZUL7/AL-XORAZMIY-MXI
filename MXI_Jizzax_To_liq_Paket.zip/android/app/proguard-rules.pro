# No custom shrinking rules are needed; release minification is disabled.
